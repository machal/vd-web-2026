$(document).ready(function() {
	
	// …
	
});
