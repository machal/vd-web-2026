function prePrint()
{
if (window.print) window.print();
else alert('V� prohl�e� nepodporuje mo�nost tisku t�mto zp�sobem. Zkuste str�nku vytisknout p��mo z rozhran� prohl�e�e.');
}

function showText(image) {
  if (image == "") {
    document.getElementById('undermenu').style.background='#ebebeb'
  }
  else {
    document.getElementById('undermenu').style.background='#ebebeb url(./cs/img/menu/'+image+') no-repeat'
  }
}


function preLoad() {
var aPreLoad = new Array();
aPreLoad[1] = new Image();	aPreLoad[1].src = './cs/img/menu/nakupuj-online_text.gif';
aPreLoad[2] = new Image();	aPreLoad[2].src = './cs/img/menu/zjisti-kdo-jsme_text.gif';
aPreLoad[3] = new Image();	aPreLoad[3].src = './cs/img/menu/bav-se_text.gif';
aPreLoad[4] = new Image();	aPreLoad[4].src = './cs/img/menu/bud-v-obraze_text.gif';
aPreLoad[5] = new Image();	aPreLoad[5].src = './cs/img/menu/najdi-prodejnu_text.gif';
aPreLoad[6] = new Image();	aPreLoad[6].src = './cs/img/menu/kontaktuj-nas_text.gif';
}

window.onload = preLoad;

