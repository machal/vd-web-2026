<?php echo("<?xml version=\"1.0\" encoding=\"windows-1250\"?>"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<head><title>Foto123</title>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1250" />
<meta http-equiv="content-language" content="cs" />
<meta http-equiv="pics-label" content='(pics-1.1 "http://www.icra.org/ratingsv02.html" comment "ICRAonline v2.0" l gen true for "http://machal.creativity.cz"  r (nz 1 vz 1 lz 1 oz 1 cz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://machal.creativity.cz"  r (n 0 s 0 v 0 l 0))' />

<meta name="author" content="" />
<meta name="keywords" content="" />
<meta name="copyright" content="" />
<meta name="MSSmartTagsPreventParsing" content="TRUE" />
<meta name="robots" content="index,follow" />

<link rel="Start" title="�vodn� str�nka" href="/" />
<link rel="Author" title="Kontakt na autora" href="mailto:info@foto123.cz" />

<style type="text/css">
  @import "css/common.css";
  @import "css/screen.css";
</style>	

</head>

<body>

<div id="header">

<p id="head">
<strong><a href="/"><img src="img/header/logo.gif" alt="Foto123.cz" width="140" height="50" /></a></strong>
</p>

<ul id="menu">
	 <li><a href="registrace">Registrace</a></li><!-- 
--><li><a href="blog/zaznamy">Z�znamy v blogu</a></li><!-- 
--><li><a href="blog/sablony">�ablony blogu</a></li><!-- 
--><li><a href="galerie">Galerie</a></li><!-- 
--><li class="last"><a href="odhlaseni">Odhl�en�</a></li>	
</ul>

</div>

<div id="contentcontainer">

<div id="content">

<h1>Registrace</h1>

<p class="error"><em>V� formul�� obsahuje chyby...</em></p>


		<div id="formregister">
			<form method="post" action="./">
				<fieldset>
					<legend>Povinn� polo�ky</legend>

					<div class="formrow" id="formular-uzivatelske-jmeno">
						<label for="s_usr_username">U�ivatelsk� jm�no</label>
						<input type="text" name="s_usr_username" id="s_usr_username" title="Vypl�te sv� U�ivatelsk� jm�no pro p�ihl�en� k Blog123" /> 
						<a href="#napoveda-uzivatelske-jmeno" onclick="return !help('uzivatelske-jmeno')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>

					<div class="formrow" id="formular-heslo">
						<label for="usr_password">Heslo</label>
						<input type="password" name="usr_password" id="usr_password" title="Vypl�te sv� Heslo pro p�ihl�en� k Blog123" /> 
						<a href="#napoveda-heslo" onclick="return !help('heslo')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>

					<div class="formrow" id="formular-potvrzeni-hesla">
						<label for="usr_passwordconfirm">Potvrzen� hesla</label>
						<input type="password" name="usr_passwordconfirm" id="usr_passwordconfirm" title="Zopakujte Heslo pro kontrolu spr�vnosti" /> 
						<a href="#napoveda-potvrzeni-hesla" onclick="return !help('potvrzeni-hesla')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>

					<div class="formrow" id="formular-prezdivka">
						<label for="s_usr_nick">P�ezd�vka (Jm�no)</label>
						<input type="text" name="s_usr_nick" id="s_usr_nick" title="Vypl�te svoj� p�ezd�vku, nebo jm�no" /> 
						<a href="#napoveda-prezdivka" onclick="return !help('prezdivka')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>

					<div class="formrow" id="formular-email">
						<label for="s_usr_email">Email</label>
						<input type="text" name="s_usr_email" id="s_usr_email" title="Vypl�te sv�j Email" /> 
						<a href="#napoveda-email" onclick="return !help('email')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>

					<script type="text/javascript" src="../js/confirmpublicemail/"></script>
				</fieldset>

				<fieldset>
					<legend>Nepovinn� polo�ky</legend>

					<div class="formrow" id="formular-email-ke-zverejneni">
						<label for="s_usr_emailpublic">Email ke zve�ejn�n�</label>
						<input type="text" name="s_usr_emailpublic" id="s_usr_emailpublic" title="Vypl�te sv�j Email pro zve�ejn�n�" /> 
						<a href="#napoveda-email-ke-zverejneni" onclick="return !help('email-ke-zverejneni')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>

					<div class="formrow" id="formular-novinky-serveru">
						<input type="checkbox" name="s_usr_newsletter" id="s_usr_newsletter" title="Za�krtn�te pol��ko, pokud si p�ejete emailem pravideln� dost�vat informace pro u�ivatele serveru Blog123" checked="checked" value="1" />
						<label for="s_usr_newsletter">ANO, p�eji si dost�vat emailem novinky serveru Blog123</label>
						<a href="#napoveda-novinky-serveru" onclick="return !help('novinky-serveru')"><span class="button orange paddinglight fontweightstrong">?</span></a>
					</div>
				</fieldset>

				<div class="formrow">
					<input type="submit" name="registrace" title="Stiskn�te tla��tko pro odesl�n� �daj� k registraci" value="Registrace" class="button orange" />
				</div>
			</form>
		</div>



</div>


<div id="rightsidecontainer">
<div id="rightside">

<div class="box">
  <h2>P�ihl�sit se</h2>
  <form>
	  <div class="content">
		<label>
		  U�ivatelsk� jm�no
		  <input type="text" class="text" />  
		</label>
		<label>
		  Heslo
		  <input type="text" class="text" />  
		</label>		
		<input type="submit" value="P�ihl�sit" class="button orange margintop10px" />
		</div>
	</form>
</div>

<div class="box">
  <h2>U�ivatel</h2>
  <form>
	  <div class="content">
		<p>Zaregistrov�n jako <strong><a href="zmena udaju">machal</a></strong>.</p>

		<input type="submit" value="Odhl�sit" class="button orange margintop10px" />
		</div>
	</form>
</div>

</div>
</div>

<div class="clearboth fontsize1px"></div>
</div>

<div id="footer">
  <p>Foto123 &mdash; Copyright 2002 &mdash; <a href="mailto:info@foto123.cz">info@foto123.cz</a></p>
</div>

</body>
</html>
