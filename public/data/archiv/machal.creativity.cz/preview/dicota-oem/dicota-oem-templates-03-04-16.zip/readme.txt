= KOD ETC. =
============

== Reseni tabulek uvnitr ==

- hlavni tabulky (id="header" a  id="main") jsou deleny do dvou dilu o 10px odsazeni po krajich a 10 dilu
- tabulky v samotnem obsahu (contentside) - konkretne tabulky s tridou "formlayout" se deli do 16 rovnomernych dilu
- kazda formatovaci tabulka ma nakonci <tr class="zerorow">, coz je prazdny radek, ktery formatuje tabulky na stejnou sirku bunek (vsechno je pak zarovnane podle jednoho gridu)

== Velikost fontu ==

- meni se v nastaveni uzivatele - options_system.html
- pri "Browser default" nacita do hlavicky akorat screen.css
- pri "Small text" nacita do hlavicky font_small.css
- pri "Large text" nacita do hlavicky font_large.css - viz index_large.html
 
== Chovani stromu ==

- defaultne je zavreny ve vsech vetvich 
- vetev All je otevrena vzdycky
- po kliknuti na "plus" obrazek se javascriptem otevre vetev, opacne pak u "minus"
- po kliknuti na obrazek slozky nebo nadpis slozky se otevre stranka catalogue.html s vypisem produktu v pravo a trvale otevrenou slozkou ve strome
- po kliknuti na samotny produkt nebo ikonu se ve stromu trvale otevre slozka a vlevo nacte produkt samotny
- po kliknuti na All se zobrazi seznam vsech produktu v catalogue.html

== Logika formularu ==

- formulare by vsechny mely splnovat stejnou logiku - navrhuju podobnou, jako je v supervisor\options_users.html
- screen se seznamem (options_users.html) obsahuje sloupec s jednoznacnym identifikatorem, ktery je proklikavaci na upravu detailu zaznamu - jine sloupce proklikavaci nejsou, pokud nevedou na jinou logickou funkci - v souboru se seznamem je vpravo nahore polozka "Add New..", ktera vede na formular pro novy zaznam
- screen s pridanim nove polozky (options_users_new.html) obsahuje formular, ktery ma 75% sirku, je centrovany a ma tucne vyznacene povinne polozky, vpravo nahore ma odkaz "Back to ..." vedouci na seznam a dole tlacitka "Save" (ulozi a vycisti formular a ohlasi to) a "Cancel" (skoci bez ulozeni zpet na seznam) - nahore jsou ukazane hlaseni pro potvrzeni ulozeni dat z formulare a chybove hlaseni, pokud data nejsou vyplnena dobre
- screen s upravou polozky (options_users_edit.html) je stejny s tim, ze ma navic tlacitko Delete pro smazani polozky... je to treba potvrdit v hlaseni podobnem tem chybovym nahore
- pozor! ostatni formulare jsou vetsinou jine (a tudiz spatne)... je nad moje sily mit vsude spravne verze, jelikoz jsem to v prubehu menil a v HTML se to blbe (prace na tyden) spravuje... verim, ze to nebude problem - prekpokladam, ze se budou vsechny generovat z jednoho systemu







